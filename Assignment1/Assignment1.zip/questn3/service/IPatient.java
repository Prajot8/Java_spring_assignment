package com.nissan.service;

public interface IPatient {
	
	String getMedicineAndBills();
	
}
