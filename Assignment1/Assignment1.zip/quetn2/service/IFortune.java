package com.nissan.service;

public interface IFortune {
	
		String getFortune();
}
