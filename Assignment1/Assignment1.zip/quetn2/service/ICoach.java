package com.nissan.service;

public interface ICoach {
	// create methods
	
	String getDailyWorkout();
}
